var l="iranDirectSettings",_="data/iranian-domains.json",h="iranDirectRemoteListUpdate",y="https://raw.githubusercontent.com/ahmadisetup/IranDirect-Releases/main/lists/iranian-domains.json",m=Object.freeze({schemaVersion:2,enabled:!1,bypassIrTld:!0,proxy:{type:"http",host:"127.0.0.1",port:10809},fallbackDirect:!1,customDirectDomains:[],forceProxyDomains:[],remoteDomains:[],remoteListUrl:y,autoUpdate:!0,remoteListVersion:null,remoteListSource:null,lastUpdateAt:null,lastUpdateError:null,lastProxyTestAt:null,lastProxyTestOk:null,lastProxyTestError:null});function c(t={}){let r=Number(t.schemaVersion??0)<2&&!t.remoteListUrl;return{...m,...t,schemaVersion:m.schemaVersion,remoteListUrl:r?y:t.remoteListUrl??m.remoteListUrl,autoUpdate:r?!0:t.autoUpdate??m.autoUpdate,proxy:{...m.proxy,...t.proxy??{}},customDirectDomains:[...t.customDirectDomains??[]],forceProxyDomains:[...t.forceProxyDomains??[]],remoteDomains:[...t.remoteDomains??[]]}}var M=/^(?!-)[a-z0-9-]{1,63}(?<!-)$/i;function w(t){if(typeof t!="string")return null;let e=t.trim().toLowerCase();if(!e)return null;e=e.replace(/^\*\./,"").replace(/^\.+|\.+$/g,"");try{e=new URL(e.includes("://")?e:`http://${e}`).hostname.toLowerCase().replace(/\.$/,"")}catch{return null}if(e==="localhost"||e.length>253||e.includes(":"))return null;let r=e.split(".");return r.length<2||r.some(o=>!M.test(o))?null:e}function i(t=[]){let e=t.map(w).filter(Boolean);return[...new Set(e)].sort((r,o)=>r<o?-1:r>o?1:0)}function b(t){let e=w(t);return e?e.startsWith("www.")?e.slice(4):e:null}function $(t,e){let r=0,o=t.length-1;for(;r<=o;){let n=Math.floor((r+o)/2),s=t[n];if(s===e)return!0;s<e?r=n+1:o=n-1}return!1}function T(t,e=[]){let r=String(t??"").toLowerCase().replace(/\.$/,"");for(;r.includes(".");){if($(e,r))return!0;r=r.slice(r.indexOf(".")+1)}return!1}var Y=Object.freeze({http:"PROXY",https:"HTTPS",socks5:"SOCKS5"});function k(t){let e=Y[t.proxy.type],r=String(t.proxy.host??"").trim(),o=Number(t.proxy.port);if(!e)throw new Error("نوع پراکسی معتبر نیست.");if(!/^[a-z0-9.-]+$/i.test(r))throw new Error("آدرس پراکسی معتبر نیست.");if(!Number.isInteger(o)||o<1||o>65535)throw new Error("پورت پراکسی باید بین ۱ تا ۶۵۵۳۵ باشد.");return`${e} ${r}:${o}`}function P(t,e=[]){let r=c(t),o=k(r),n=r.fallbackDirect?`${o}; DIRECT`:o,s=i([...e,...r.remoteDomains,...r.customDirectDomains]),a=i(r.forceProxyDomains);return`
var IRAN_DIRECT_DOMAINS = ${JSON.stringify(s)};
var IRAN_FORCE_PROXY_DOMAINS = ${JSON.stringify(a)};
var IRAN_PROXY = ${JSON.stringify(n)};
var IRAN_BYPASS_TLD = ${r.bypassIrTld?"true":"false"};

function iranIncludesSorted(domains, target) {
  var low = 0;
  var high = domains.length - 1;

  while (low <= high) {
    var middle = Math.floor((low + high) / 2);
    var value = domains[middle];
    if (value === target) {
      return true;
    }
    if (value < target) {
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return false;
}

function iranMatchesAny(host, domains) {
  var candidate = host;
  while (candidate.indexOf(".") !== -1) {
    if (iranIncludesSorted(domains, candidate)) {
      return true;
    }
    candidate = candidate.slice(candidate.indexOf(".") + 1);
  }
  return false;
}

function FindProxyForURL(url, host) {
  host = host.toLowerCase().replace(/\\.$/, "");

  if (
    isPlainHostName(host) ||
    host === "localhost" ||
    host === "::1" ||
    shExpMatch(host, "127.*")
  ) {
    return "DIRECT";
  }

  if (iranMatchesAny(host, IRAN_FORCE_PROXY_DOMAINS)) {
    return IRAN_PROXY;
  }

  if (IRAN_BYPASS_TLD && (host === "ir" || dnsDomainIs(host, ".ir"))) {
    return "DIRECT";
  }

  if (iranMatchesAny(host, IRAN_DIRECT_DOMAINS)) {
    return "DIRECT";
  }

  return IRAN_PROXY;
}
`.trim()}var d=Object.freeze({DIRECT:"direct",PROXY:"proxy",SYSTEM:"system"});function v(t){let e=String(t??"").toLowerCase().replace(/\.$/,"");return e==="localhost"||e==="::1"||e.startsWith("127.")||!e.includes(".")}function E(t,e,r=[]){let o=c(e),n=String(t??"").toLowerCase().replace(/\.$/,"");if(!o.enabled)return{route:d.SYSTEM,reason:"extension-disabled"};if(v(n))return{route:d.DIRECT,reason:"local-address"};let s=i(o.forceProxyDomains);if(T(n,s))return{route:d.PROXY,reason:"forced-proxy"};if(o.bypassIrTld&&(n==="ir"||n.endsWith(".ir")))return{route:d.DIRECT,reason:"ir-domain"};let a=i([...r,...o.remoteDomains,...o.customDirectDomains]);return T(n,a)?{route:d.DIRECT,reason:"direct-list"}:{route:d.PROXY,reason:"default-proxy"}}var D=Object.freeze([{type:"http",port:10809},{type:"http",port:7890},{type:"http",port:12334},{type:"http",port:2080},{type:"http",port:8080},{type:"socks5",port:10808},{type:"socks5",port:7891},{type:"socks5",port:1080}]);var I,g,U="https://api.github.com/zen",z=2200;async function S(){return I||(I=fetch(chrome.runtime.getURL(_)).then(t=>{if(!t.ok)throw new Error("فهرست داخلی سایت‌ها بارگذاری نشد.");return t.json()}).then(t=>i(t.domains??t))),I}async function u(){let t=await chrome.storage.local.get(l);return c(t[l])}async function p(t){let e=c(t);return e.customDirectDomains=i(e.customDirectDomains),e.forceProxyDomains=i(e.forceProxyDomains),e.remoteDomains=i(e.remoteDomains),P(e,[]),await chrome.storage.local.set({[l]:e}),await R(e),await x(e),e}async function O(){(await chrome.storage.local.get(l))[l]||await chrome.storage.local.set({[l]:c(m)})}async function x(t){let e=c(t);if(!e.enabled){await chrome.proxy.settings.set({value:{mode:"system"},scope:"regular"}),await L(!1);return}let r=await S(),o=P(e,r);await chrome.proxy.settings.set({value:{mode:"pac_script",pacScript:{data:o,mandatory:!0}},scope:"regular"}),await L(!0)}async function L(t){await chrome.action.setBadgeText({text:t?"ON":""}),await chrome.action.setBadgeBackgroundColor({color:"#159B72"})}async function R(t){t.autoUpdate&&t.remoteListUrl?await chrome.alarms.create(h,{delayInMinutes:5,periodInMinutes:1440}):await chrome.alarms.clear(h)}function X(t){let e=Array.isArray(t)?t:t?.domains;if(!Array.isArray(e))throw new Error("ساختار فایل باید آرایه یا دارای کلید domains باشد.");if(e.length>5e4)throw new Error("فهرست دریافتی بیش از اندازه بزرگ است.");let r=i(e);if(r.length===0)throw new Error("فهرست دریافتی هیچ دامنه معتبری ندارد.");return{domains:r,version:typeof t?.version=="string"?t.version.slice(0,64):null,source:typeof t?.source=="string"?t.source.slice(0,200):B(t?.sources)}}function B(t){return Array.isArray(t)&&t.filter(e=>typeof e=="string").slice(0,4).join(" + ").slice(0,200)||null}async function N(){let t=await u();if(!t.remoteListUrl)throw new Error("آدرس فهرست آنلاین وارد نشده است.");let e;try{e=new URL(t.remoteListUrl)}catch{throw new Error("آدرس فهرست آنلاین معتبر نیست.")}if(e.protocol!=="https:")throw new Error("فهرست آنلاین باید از HTTPS استفاده کند.");try{let r=await fetch(e.href,{cache:"no-store",headers:{Accept:"application/json"}});if(!r.ok)throw new Error(`دریافت فهرست با خطای ${r.status} مواجه شد.`);let o=X(await r.json()),n=await p({...t,remoteDomains:o.domains,remoteListVersion:o.version,remoteListSource:o.source,lastUpdateAt:new Date().toISOString(),lastUpdateError:null});return{count:o.domains.length,version:o.version,lastUpdateAt:n.lastUpdateAt,official:e.href===y}}catch(r){throw await chrome.storage.local.set({[l]:{...t,lastUpdateError:r.message}}),r}}async function C(t,e){let r={...t,lastProxyTestAt:new Date().toISOString(),lastProxyTestOk:e.ok,lastProxyTestError:e.error??null};return await chrome.storage.local.set({[l]:r}),r}async function H(){let[t,e]=await Promise.all([u(),S()]);if(!t.enabled)throw new Error("برای تست، ابتدا IranDirect را فعال و تنظیمات را ذخیره کنید.");if(E("api.github.com",t,e).route!=="proxy")throw new Error("دامنه تست در فهرست مستقیم قرار دارد؛ api.github.com را از فهرست مستقیم حذف کنید.");let o=new AbortController,n=setTimeout(()=>o.abort(),1e4),s=Date.now();try{await fetch(`${U}?iran-direct=${Date.now()}`,{cache:"no-store",headers:{Accept:"text/plain"},signal:o.signal});let a=await C(t,{ok:!0});return{ok:!0,latencyMs:Date.now()-s,testedAt:a.lastProxyTestAt}}catch(a){let f=a?.name==="AbortError"?"زمان اتصال تمام شد. احتمالاً نوع یا پورت پراکسی اشتباه است.":"اتصال خارجی از پراکسی برقرار نشد. نوع، آدرس و پورت را بررسی کنید.";throw await C(t,{ok:!1,error:f}),new Error(f)}finally{clearTimeout(n)}}async function F(t=z){let e=new AbortController,r=setTimeout(()=>e.abort(),t);try{return(await fetch(`${U}?iran-direct-detect=${Date.now()}-${Math.random()}`,{cache:"no-store",headers:{Accept:"text/plain"},signal:e.signal})).ok}catch{return!1}finally{clearTimeout(r)}}async function W(){let t=await u(),e="127.0.0.1",r=null;try{for(let o of D){let n=c({...t,enabled:!0,fallbackDirect:!1,forceProxyDomains:[...t.forceProxyDomains,"api.github.com"],proxy:{type:o.type,host:e,port:o.port}});if(await x(n),await F()){let s=new Date().toISOString(),a=await p({...t,proxy:{type:o.type,host:e,port:o.port},lastProxyTestAt:s,lastProxyTestOk:!0,lastProxyTestError:null});return r=o,{found:!0,candidate:a.proxy,testedCount:D.indexOf(o)+1,settings:a}}}return{found:!1,testedCount:D.length}}finally{r||await x(t)}}async function j(){if(g)throw new Error("تشخیص خودکار پورت از قبل در حال اجراست.");g=W();try{return await g}finally{g=null}}async function V(){await O();let[t,e,r]=await Promise.all([u(),S(),chrome.proxy.settings.get({incognito:!1})]);return{settings:t,bundledDomainCount:e.length,directDomainCount:i([...e,...t.remoteDomains,...t.customDirectDomains]).length,levelOfControl:r.levelOfControl}}async function G(t,e){let r=w(t),o=b(r);if(!o)throw new Error("دامنه معتبر نیست.");let n=await u(),s=new Set([r,o]),a=n.customDirectDomains.filter(A=>!s.has(A)),f=n.forceProxyDomains.filter(A=>!s.has(A));if(e==="direct")a.push(o);else if(e==="proxy")f.push(o);else if(e!=="auto")throw new Error("مسیر انتخاب‌شده معتبر نیست.");return{settings:await p({...n,customDirectDomains:a,forceProxyDomains:f}),domain:o}}async function K(t){switch(t?.type){case"get-state":return V();case"save-settings":return{settings:await p(t.settings)};case"set-enabled":{let e=await u();return{settings:await p({...e,enabled:!!t.enabled})}}case"classify-host":{let[e,r]=await Promise.all([u(),S()]);return E(t.host,e,r)}case"set-domain-route":return G(t.domain,t.route);case"update-remote-list":return N();case"test-proxy":return H();case"detect-proxy":return j();default:throw new Error("درخواست ناشناخته است.")}}chrome.runtime.onMessage.addListener((t,e,r)=>(K(t).then(o=>r({ok:!0,data:o})).catch(o=>r({ok:!1,error:o?.message??"خطای ناشناخته"})),!0));chrome.runtime.onInstalled.addListener(async()=>{await O();let t=await u();await R(t),await L(t.enabled)});chrome.runtime.onStartup.addListener(async()=>{await O();let t=await u();await x(t),await R(t)});chrome.alarms.onAlarm.addListener(t=>{t.name===h&&N().catch(()=>{})});
