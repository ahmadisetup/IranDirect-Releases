var l="iranDirectSettings",_="data/iranian-domains.json",h="iranDirectRemoteListUpdate",w="https://raw.githubusercontent.com/ahmadisetup/IranDirect-Releases/main/lists/iranian-domains.json",p=Object.freeze({schemaVersion:3,enabled:!1,bypassIrTld:!0,proxy:{type:"http",host:"127.0.0.1",port:10809},fallbackDirect:!1,autoDetectSystemProxy:!0,customDirectDomains:[],forceProxyDomains:[],remoteDomains:[],remoteListUrl:w,autoUpdate:!0,remoteListVersion:null,remoteListSource:null,lastUpdateAt:null,lastUpdateError:null,lastProxyTestAt:null,lastProxyTestOk:null,lastProxyTestError:null,lastProxyDetectionAt:null,lastProxyDetectionSource:null});function c(t={}){let e=Number(t.schemaVersion??0)<2,r=Number(t.schemaVersion??0)<3,o=e&&!t.remoteListUrl;return{...p,...t,schemaVersion:p.schemaVersion,autoDetectSystemProxy:r?!0:t.autoDetectSystemProxy??p.autoDetectSystemProxy,remoteListUrl:o?w:t.remoteListUrl??p.remoteListUrl,autoUpdate:o?!0:t.autoUpdate??p.autoUpdate,proxy:{...p.proxy,...t.proxy??{}},customDirectDomains:[...t.customDirectDomains??[]],forceProxyDomains:[...t.forceProxyDomains??[]],remoteDomains:[...t.remoteDomains??[]]}}var z=/^(?!-)[a-z0-9-]{1,63}(?<!-)$/i;function x(t){if(typeof t!="string")return null;let e=t.trim().toLowerCase();if(!e)return null;e=e.replace(/^\*\./,"").replace(/^\.+|\.+$/g,"");try{e=new URL(e.includes("://")?e:`http://${e}`).hostname.toLowerCase().replace(/\.$/,"")}catch{return null}if(e==="localhost"||e.length>253||e.includes(":"))return null;let r=e.split(".");return r.length<2||r.some(o=>!z.test(o))?null:e}function i(t=[]){let e=t.map(x).filter(Boolean);return[...new Set(e)].sort((r,o)=>r<o?-1:r>o?1:0)}function C(t){let e=x(t);return e?e.startsWith("www.")?e.slice(4):e:null}function v(t,e){let r=0,o=t.length-1;for(;r<=o;){let n=Math.floor((r+o)/2),s=t[n];if(s===e)return!0;s<e?r=n+1:o=n-1}return!1}function P(t,e=[]){let r=String(t??"").toLowerCase().replace(/\.$/,"");for(;r.includes(".");){if(v(e,r))return!0;r=r.slice(r.indexOf(".")+1)}return!1}var H=Object.freeze({http:"PROXY",https:"HTTPS",socks5:"SOCKS5"});function X(t){let e=H[t.proxy.type],r=String(t.proxy.host??"").trim(),o=Number(t.proxy.port);if(!e)throw new Error("نوع پراکسی معتبر نیست.");if(!/^[a-z0-9.-]+$/i.test(r))throw new Error("آدرس پراکسی معتبر نیست.");if(!Number.isInteger(o)||o<1||o>65535)throw new Error("پورت پراکسی باید بین ۱ تا ۶۵۵۳۵ باشد.");return`${e} ${r}:${o}`}function T(t,e=[]){let r=c(t),o=X(r),n=r.fallbackDirect?`${o}; DIRECT`:o,s=i([...e,...r.remoteDomains,...r.customDirectDomains]),a=i(r.forceProxyDomains);return`
var IRAN_DIRECT_DOMAINS = ${JSON.stringify(s)};
var IRAN_FORCE_PROXY_DOMAINS = ${JSON.stringify(a)};
var IRAN_PROXY = ${JSON.stringify(n)};
var IRAN_BYPASS_TLD = ${r.bypassIrTld?"true":"false"};

function iranIncludesSorted(domains, target) {
  var low = 0;
  var high = domains.length - 1;

  while (low <= high) {
    var middle = Math.floor((low + high) / 2);
    var value = domains[middle];
    if (value === target) {
      return true;
    }
    if (value < target) {
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return false;
}

function iranMatchesAny(host, domains) {
  var candidate = host;
  while (candidate.indexOf(".") !== -1) {
    if (iranIncludesSorted(domains, candidate)) {
      return true;
    }
    candidate = candidate.slice(candidate.indexOf(".") + 1);
  }
  return false;
}

function FindProxyForURL(url, host) {
  host = host.toLowerCase().replace(/\\.$/, "");

  if (
    isPlainHostName(host) ||
    host === "localhost" ||
    host === "::1" ||
    shExpMatch(host, "127.*")
  ) {
    return "DIRECT";
  }

  if (iranMatchesAny(host, IRAN_FORCE_PROXY_DOMAINS)) {
    return IRAN_PROXY;
  }

  if (IRAN_BYPASS_TLD && (host === "ir" || dnsDomainIs(host, ".ir"))) {
    return "DIRECT";
  }

  if (iranMatchesAny(host, IRAN_DIRECT_DOMAINS)) {
    return "DIRECT";
  }

  return IRAN_PROXY;
}
`.trim()}var d=Object.freeze({DIRECT:"direct",PROXY:"proxy",SYSTEM:"system"});function B(t){let e=String(t??"").toLowerCase().replace(/\.$/,"");return e==="localhost"||e==="::1"||e.startsWith("127.")||!e.includes(".")}function A(t,e,r=[]){let o=c(e),n=String(t??"").toLowerCase().replace(/\.$/,"");if(!o.enabled)return{route:d.SYSTEM,reason:"extension-disabled"};if(B(n))return{route:d.DIRECT,reason:"local-address"};let s=i(o.forceProxyDomains);if(P(n,s))return{route:d.PROXY,reason:"forced-proxy"};if(o.bypassIrTld&&(n==="ir"||n.endsWith(".ir")))return{route:d.DIRECT,reason:"ir-domain"};let a=i([...r,...o.remoteDomains,...o.customDirectDomains]);return P(n,a)?{route:d.DIRECT,reason:"direct-list"}:{route:d.PROXY,reason:"default-proxy"}}var N=Object.freeze([{type:"http",port:10809},{type:"http",port:7890},{type:"http",port:12334},{type:"http",port:2080},{type:"http",port:8080},{type:"socks5",port:10808},{type:"socks5",port:7891},{type:"socks5",port:1080}]);var b="com.ahmadisetup.irandirect",F=new Set(["http","https","socks5"]),W=/^[a-z0-9.-]+$/i;function E(t){if(!t?.ok||!t?.found||!t.proxy)return null;let e=String(t.proxy.type??"").toLowerCase(),r=String(t.proxy.host??"").trim().toLowerCase(),o=Number(t.proxy.port);return!F.has(e)||!W.test(r)||!Number.isInteger(o)||o<1||o>65535?null:{type:e,host:r,port:o,source:String(t.proxy.source??"windows-system-proxy").slice(0,80)}}var I,D,M="https://api.github.com/zen",j=2200;async function V(){try{let t=await chrome.storage.managed.get(["autoDetectSystemProxy","proxyType","proxyHost","proxyPort"]);return t.autoDetectSystemProxy===!1?null:E({ok:!0,found:!!(t.proxyType&&t.proxyHost&&t.proxyPort),proxy:{type:t.proxyType,host:t.proxyHost,port:t.proxyPort,source:"chrome-managed-policy"}})}catch{return null}}async function G(){try{let t=await chrome.runtime.sendNativeMessage(b,{action:"detectProxy"});return E(t)}catch{return null}}async function $(){return await V()??await G()}async function k(t){let e=c(t);if(!e.autoDetectSystemProxy)return e;let r=await $();if(!r||e.proxy.type===r.type&&e.proxy.host===r.host&&e.proxy.port===r.port)return e;let n=c({...e,proxy:{type:r.type,host:r.host,port:r.port},lastProxyDetectionAt:new Date().toISOString(),lastProxyDetectionSource:r.source,lastProxyTestOk:null,lastProxyTestError:null});return await chrome.storage.local.set({[l]:n}),n}async function g(){return I||(I=fetch(chrome.runtime.getURL(_)).then(t=>{if(!t.ok)throw new Error("فهرست داخلی سایت‌ها بارگذاری نشد.");return t.json()}).then(t=>i(t.domains??t))),I}async function u(){let t=await chrome.storage.local.get(l);return c(t[l])}async function y(t){let e=c(t);return e.customDirectDomains=i(e.customDirectDomains),e.forceProxyDomains=i(e.forceProxyDomains),e.remoteDomains=i(e.remoteDomains),T(e,[]),await chrome.storage.local.set({[l]:e}),await R(e),await f(e),e}async function L(){(await chrome.storage.local.get(l))[l]||await chrome.storage.local.set({[l]:c(p)})}async function f(t){let e=c(t);if(!e.enabled){await chrome.proxy.settings.set({value:{mode:"system"},scope:"regular"}),await O(!1);return}let r=await g(),o=T(e,r);await chrome.proxy.settings.set({value:{mode:"pac_script",pacScript:{data:o,mandatory:!0}},scope:"regular"}),await O(!0)}async function O(t){await chrome.action.setBadgeText({text:t?"ON":""}),await chrome.action.setBadgeBackgroundColor({color:"#159B72"})}async function R(t){t.autoUpdate&&t.remoteListUrl?await chrome.alarms.create(h,{delayInMinutes:5,periodInMinutes:1440}):await chrome.alarms.clear(h)}function K(t){let e=Array.isArray(t)?t:t?.domains;if(!Array.isArray(e))throw new Error("ساختار فایل باید آرایه یا دارای کلید domains باشد.");if(e.length>5e4)throw new Error("فهرست دریافتی بیش از اندازه بزرگ است.");let r=i(e);if(r.length===0)throw new Error("فهرست دریافتی هیچ دامنه معتبری ندارد.");return{domains:r,version:typeof t?.version=="string"?t.version.slice(0,64):null,source:typeof t?.source=="string"?t.source.slice(0,200):J(t?.sources)}}function J(t){return Array.isArray(t)&&t.filter(e=>typeof e=="string").slice(0,4).join(" + ").slice(0,200)||null}async function Y(){let t=await u();if(!t.remoteListUrl)throw new Error("آدرس فهرست آنلاین وارد نشده است.");let e;try{e=new URL(t.remoteListUrl)}catch{throw new Error("آدرس فهرست آنلاین معتبر نیست.")}if(e.protocol!=="https:")throw new Error("فهرست آنلاین باید از HTTPS استفاده کند.");try{let r=await fetch(e.href,{cache:"no-store",headers:{Accept:"application/json"}});if(!r.ok)throw new Error(`دریافت فهرست با خطای ${r.status} مواجه شد.`);let o=K(await r.json()),n=await y({...t,remoteDomains:o.domains,remoteListVersion:o.version,remoteListSource:o.source,lastUpdateAt:new Date().toISOString(),lastUpdateError:null});return{count:o.domains.length,version:o.version,lastUpdateAt:n.lastUpdateAt,official:e.href===w}}catch(r){throw await chrome.storage.local.set({[l]:{...t,lastUpdateError:r.message}}),r}}async function U(t,e){let r={...t,lastProxyTestAt:new Date().toISOString(),lastProxyTestOk:e.ok,lastProxyTestError:e.error??null};return await chrome.storage.local.set({[l]:r}),r}async function q(){let[t,e]=await Promise.all([u(),g()]);if(!t.enabled)throw new Error("برای تست، ابتدا IranDirect را فعال و تنظیمات را ذخیره کنید.");if(A("api.github.com",t,e).route!=="proxy")throw new Error("دامنه تست در فهرست مستقیم قرار دارد؛ api.github.com را از فهرست مستقیم حذف کنید.");let o=new AbortController,n=setTimeout(()=>o.abort(),1e4),s=Date.now();try{await fetch(`${M}?iran-direct=${Date.now()}`,{cache:"no-store",headers:{Accept:"text/plain"},signal:o.signal});let a=await U(t,{ok:!0});return{ok:!0,latencyMs:Date.now()-s,testedAt:a.lastProxyTestAt}}catch(a){let m=a?.name==="AbortError"?"زمان اتصال تمام شد. احتمالاً نوع یا پورت پراکسی اشتباه است.":"اتصال خارجی از پراکسی برقرار نشد. نوع، آدرس و پورت را بررسی کنید.";throw await U(t,{ok:!1,error:m}),new Error(m)}finally{clearTimeout(n)}}async function Q(t=j){let e=new AbortController,r=setTimeout(()=>e.abort(),t);try{return(await fetch(`${M}?iran-direct-detect=${Date.now()}-${Math.random()}`,{cache:"no-store",headers:{Accept:"text/plain"},signal:e.signal})).ok}catch{return!1}finally{clearTimeout(r)}}async function Z(){let t=await u(),e=null;try{let r=[];if(t.autoDetectSystemProxy){let o=await $();o&&r.push(o)}for(let o of N){let n={...o,host:"127.0.0.1",source:"common-port-scan"};r.some(s=>s.type===n.type&&s.host===n.host&&s.port===n.port)||r.push(n)}for(let o=0;o<r.length;o+=1){let n=r[o],s=c({...t,enabled:!0,fallbackDirect:!1,forceProxyDomains:[...t.forceProxyDomains,"api.github.com"],proxy:{type:n.type,host:n.host,port:n.port}});if(await f(s),await Q()){let a=new Date().toISOString(),m=await y({...t,proxy:{type:n.type,host:n.host,port:n.port},lastProxyDetectionAt:a,lastProxyDetectionSource:n.source,lastProxyTestAt:a,lastProxyTestOk:!0,lastProxyTestError:null});return e=n,{found:!0,candidate:m.proxy,testedCount:o+1,method:n.source,settings:m}}}return{found:!1,testedCount:r.length}}finally{e||await f(t)}}async function tt(){if(D)throw new Error("تشخیص خودکار پورت از قبل در حال اجراست.");D=Z();try{return await D}finally{D=null}}async function et(){await L();let[t,e,r]=await Promise.all([u(),g(),chrome.proxy.settings.get({incognito:!1})]);return{settings:t,bundledDomainCount:e.length,directDomainCount:i([...e,...t.remoteDomains,...t.customDirectDomains]).length,levelOfControl:r.levelOfControl}}async function rt(t,e){let r=x(t),o=C(r);if(!o)throw new Error("دامنه معتبر نیست.");let n=await u(),s=new Set([r,o]),a=n.customDirectDomains.filter(S=>!s.has(S)),m=n.forceProxyDomains.filter(S=>!s.has(S));if(e==="direct")a.push(o);else if(e==="proxy")m.push(o);else if(e!=="auto")throw new Error("مسیر انتخاب‌شده معتبر نیست.");return{settings:await y({...n,customDirectDomains:a,forceProxyDomains:m}),domain:o}}async function ot(t){switch(t?.type){case"get-state":return et();case"save-settings":return{settings:await y(t.settings)};case"set-enabled":{let e=await u();return{settings:await y({...e,enabled:!!t.enabled})}}case"classify-host":{let[e,r]=await Promise.all([u(),g()]);return A(t.host,e,r)}case"set-domain-route":return rt(t.domain,t.route);case"update-remote-list":return Y();case"test-proxy":return q();case"detect-proxy":return tt();default:throw new Error("درخواست ناشناخته است.")}}chrome.runtime.onMessage.addListener((t,e,r)=>(ot(t).then(o=>r({ok:!0,data:o})).catch(o=>r({ok:!1,error:o?.message??"خطای ناشناخته"})),!0));chrome.runtime.onInstalled.addListener(async()=>{await L();let t=await k(await u());await f(t),await R(t),await O(t.enabled)});chrome.runtime.onStartup.addListener(async()=>{await L();let t=await k(await u());await f(t),await R(t)});chrome.alarms.onAlarm.addListener(t=>{t.name===h&&Y().catch(()=>{})});
